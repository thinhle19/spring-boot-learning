package com.thinhle.democrm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
