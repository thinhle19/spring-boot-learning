package com.thinhle.democrm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoCrmApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoCrmApplication.class, args);
	}

}
